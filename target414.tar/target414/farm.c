/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_393(unsigned *p)
{
    *p = 3058811672U;
}

unsigned getval_458()
{
    return 3351742792U;
}

void setval_110(unsigned *p)
{
    *p = 3619917912U;
}

unsigned getval_160()
{
    return 3284633928U;
}

unsigned getval_113()
{
    return 2425394264U;
}

unsigned addval_368(unsigned x)
{
    return x + 2428993864U;
}

unsigned addval_123(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_447()
{
    return 2425378911U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_386(unsigned *p)
{
    *p = 3286272320U;
}

unsigned addval_346(unsigned x)
{
    return x + 3674789513U;
}

void setval_293(unsigned *p)
{
    *p = 3523789065U;
}

unsigned addval_344(unsigned x)
{
    return x + 3526940313U;
}

void setval_134(unsigned *p)
{
    *p = 3381971593U;
}

void setval_286(unsigned *p)
{
    *p = 3221799309U;
}

unsigned getval_150()
{
    return 3767355423U;
}

void setval_273(unsigned *p)
{
    *p = 3372275337U;
}

unsigned addval_237(unsigned x)
{
    return x + 3374893705U;
}

void setval_349(unsigned *p)
{
    *p = 3767093362U;
}

void setval_385(unsigned *p)
{
    *p = 3767093290U;
}

unsigned getval_192()
{
    return 3247489417U;
}

unsigned getval_489()
{
    return 3286272840U;
}

unsigned addval_208(unsigned x)
{
    return x + 3223901833U;
}

unsigned getval_266()
{
    return 2425408141U;
}

unsigned getval_488()
{
    return 3223377545U;
}

void setval_191(unsigned *p)
{
    *p = 3676362409U;
}

unsigned addval_222(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_328(unsigned x)
{
    return x + 3281046153U;
}

void setval_463(unsigned *p)
{
    *p = 3252717896U;
}

unsigned addval_239(unsigned x)
{
    return x + 3281109385U;
}

void setval_169(unsigned *p)
{
    *p = 3676357005U;
}

unsigned getval_229()
{
    return 3687039369U;
}

unsigned addval_366(unsigned x)
{
    return x + 3222847881U;
}

void setval_249(unsigned *p)
{
    *p = 3523794561U;
}

unsigned getval_452()
{
    return 3281043849U;
}

void setval_120(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_122()
{
    return 3378563721U;
}

unsigned addval_170(unsigned x)
{
    return x + 3374369417U;
}

void setval_264(unsigned *p)
{
    *p = 3281046155U;
}

unsigned getval_441()
{
    return 3676883593U;
}

unsigned getval_416()
{
    return 3229931144U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
